python demo/volleyball_joint_feature_extraction.py \
              --dataset_path /home/test03/shelterX/code/Group-Activity-Recognition-master/data/volleyball\
              --track_path /home/test03/shelterX/code/Group-Activity-Recognition-master/data/volleyball/tracks_normalized.pkl \
              --save_path /home/test03/shelterX/code/Group-Activity-Recognition-master/data/volleyball/joints